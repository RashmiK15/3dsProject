package com.java.layer3;

import java.util.List;

import com.java.layer2.Fir;

public interface FirDAO {
  List<Fir> getFirs();
}