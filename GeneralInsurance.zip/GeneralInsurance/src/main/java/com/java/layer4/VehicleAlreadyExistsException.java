package com.java.layer4;

public class VehicleAlreadyExistsException extends Exception {
	public VehicleAlreadyExistsException(String str) {
		super(str);
		
	}
}
